#include <iostream>
#include<string>

using namespace std;

int main() {
    string username;
    cout << "Xin chao, ten toi la Hoa!" << endl;
    cout << "Ten ban la gi?" << endl;
    cin >> username;
    cout << "Chao ban, " << username << "!" << endl;
	system("pause");
    return 0;
}
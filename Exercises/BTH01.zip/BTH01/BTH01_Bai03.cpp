#include<iostream>

using namespace std;

int main() {
    cout << "  /////" << endl;
    cout << " +-----+" << endl;
    cout << "(| o o |)" << endl;
    cout << " |  ^  | " << endl;
    cout << " | ,_, |" << endl;
    cout << " +-----+" << endl;
    system("pause");
    return 0;
}
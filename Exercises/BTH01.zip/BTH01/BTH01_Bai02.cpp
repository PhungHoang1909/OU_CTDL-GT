#include<iostream>

using namespace std;

int main() {
    cout << "***************************" << endl;
    cout << "*     Bai thuc hanh 1     *" << endl;
    cout << "*     Mon: CSLT           *" << endl;
    cout << "*     MSSV: 2151013026    *" << endl;
    cout << "***************************" << endl;
    system("pause");
    return 0;
}
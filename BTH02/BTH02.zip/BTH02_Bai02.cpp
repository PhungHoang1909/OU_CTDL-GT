#include<iostream>

using namespace std;

int main() {
    int dai, rong;
    int dientich;
    cout << "Nhap do dai 2 canh: ";
    cin >> dai >> rong;
    dientich = dai * rong;
    cout << "Dien tich hcn la: " << dientich << endl;
    system("pause");
    return 0;
}
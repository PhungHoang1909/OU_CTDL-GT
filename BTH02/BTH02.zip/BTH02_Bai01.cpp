#include<iostream>

using namespace std;

int main()
{
    int canh;
    cout << "Nhap canh hinh vuong: ";
    cin >> canh;
    int dientich = canh * canh;
    cout << "Dien tich hinh vuong: " << dientich << endl;
    system("pause");
    return 0;
}